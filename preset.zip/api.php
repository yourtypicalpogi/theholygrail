<?php 

require 'preset.php';

$requests = new Requests;

$proxy = 'proxy:port';
$userpass_array = [
   'username:password',
];

$requests->proxy = $proxy;
$requests->userpass = $userpass_array[array_rand($userpass_array)];

$url = "https://api.ipify.org/?format=json";
$headers = [
	"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
	"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
	"Accept-Language: en-US,en;q=0.5",
	"Connection: keep-alive",
	"Upgrade-Insecure-Requests: 1",
	"Sec-Fetch-Dest: document",
	"Sec-Fetch-Mode: navigate",
	"Sec-Fetch-Site: none",
	"Sec-Fetch-User: ?1",
	"Priority: u=1",
];
$response = $requests->get($url, $headers);
$ip = json_decode($response)->ip;