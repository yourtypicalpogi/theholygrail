<?php

error_reporting(E_ERROR|E_PARSE);

class Requests {

     public $cookies;

     public $proxy;

     public $userpass;

     public function __construct() {
          $this->cookies = tempnam(__DIR__.'/tmp', 'cookie');
     }

     public function __destruct() {
          if(file_exists($this->cookies)) {
               unlink($this->cookies);
          }
     }

     public function get($url, $headers) {
          $ch = curl_init();
          curl_setopt_array($ch, [
               CURLOPT_URL => $url,
               CURLOPT_HEADER => false,
               CURLOPT_RETURNTRANSFER => true,
               CURLOPT_FOLLOWLOCATION => true,
               CURLOPT_SSL_VERIFYPEER => false,
               CURLOPT_SSL_VERIFYHOST => false,
               CURLOPT_PROXY => $this->proxy,
               CURLOPT_PROXYUSERPWD =>  $this->userpass,
               CURLOPT_COOKIEFILE => $this->cookies,
               CURLOPT_COOKIEJAR => $this->cookies,
               CURLOPT_HTTPHEADER => $headers,
          ]);
          
          $response = curl_exec($ch);
          curl_close($ch);

          return $response;
     }
     public function post($url, $headers, $post) {
          $ch = curl_init();
          curl_setopt_array($ch, [
               CURLOPT_URL => $url,
               CURLOPT_HEADER => false,
               CURLOPT_RETURNTRANSFER => true,
               CURLOPT_FOLLOWLOCATION => true,
               CURLOPT_SSL_VERIFYPEER => false,
               CURLOPT_SSL_VERIFYHOST => false,
               CURLOPT_PROXY => $this->proxy,
               CURLOPT_PROXYUSERPWD =>  $this->userpass,
               CURLOPT_COOKIEFILE => $this->cookies,
               CURLOPT_COOKIEJAR => $this->cookies,
               CURLOPT_HTTPHEADER => $headers,
               CURLOPT_POSTFIELDS => $post,
          ]);

          $response = curl_exec($ch);
          curl_close($ch);

          return $response;
     }
}

# Functions 

function get_str($string, $start, $end) {
     return explode($end, explode($start, $string)[1])[0];
}

function rand_str($length) {
     return substr(str_shuffle('abcdefghijklmnopqrstuvwxyz'), 0, $length);
}

function rand_int($length) {
     return substr(str_shuffle('0123456789'), 0, $length);
}
function uuid() {
     return vsprintf( '%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex(random_bytes(16)), 4) );
}

extract($_GET);
$explode = explode("|", $card);
$cc = $explode[0];
$mm = $explode[1];
$yyyy = $explode[2];
$cvv = $explode[3];
$last4 = substr($cc, -4);
$brand = $cc[0] == "4" ? "visa" : "mc";
$initial = $brand == "visa" ? "VI" : "MC";
$yy = (strlen($yy) == 4) ? substr($yy, 2) : $yy;
$m = (strlen($mm) == 2) ? substr($mm, 1) : $mm;

?>